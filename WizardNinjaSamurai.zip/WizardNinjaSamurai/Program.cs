﻿using System;
using WizardNinjaSamurai.WizardClass;

namespace WizardNinjaSamurai
{
    class Program
    {
        static void Main (string[] args)
        {
            Console.WriteLine ("Hello World!");
            Wizard wiz = new Wizard ("Merlin", 10, 10);
        }
    }
}